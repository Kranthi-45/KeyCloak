(function(window){ 
    // function isUsernameEmailPrint(mymsg) {
    //     console.log("mymsg",mymsg);
    //     return mymsg;
    // }
    
    function loginScript() {
        let _loginLibraryObject = {};
        // _loginLibraryObject.loginScriptFunction = function(registrationSuccessMsgRegistered,registrationSuccessMsgVerified,registrationSuccessMsgUpdated,registrationSuccessMsgUsed,loginErrorMsgIncorrect,loginResetPasswordInstructionMsg,loginAccountDisabeledMsg,loginLinkExpiredMsg,isUsernameEmailConfig,loginPasswordMinCharecters,emailRegex,usernameRegex,loginIncorrectUsernameMsg,loginIncorrectPasswordMsg){
        _loginLibraryObject.loginScriptFunction = function(emailRegex,isUsernameEmailConfig,loginPasswordMinCharecters,usernameRegex,loginErrorMsgIncorrect){
        const AUTOFILLED = 'autofilled'
        const onAutoFillStart = (el) => {
            el.classList.add(AUTOFILLED);
            console.log("added class autofilled",el);
            console.log("password value issssss",document.getElementById("password").value,document.getElementById("username").value);
        }
        const onAutoFillCancel = (el) => {
            el.classList.remove(AUTOFILLED);
            console.log("!!!!!!!!!",el)
        }
        const onAnimationStart = ({ target, animationName }) => {
        switch (animationName) {
            case 'onAutoFillStart':
                return onAutoFillStart(target)
            case 'onAutoFillCancel':
                return onAutoFillCancel(target)
        }
        };
        
        document.addEventListener('DOMContentLoaded', (event) => {
            console.log("input value issssss",document.getElementById("username").value);
            document.querySelector('input').addEventListener('animationstart', onAnimationStart, false);
            let link = localStorage.getItem("link");
            let eLink = localStorage.getItem("eVerify");
            let pLink = localStorage.getItem("passUpdate");
            let errorTxt = localStorage.getItem("errorText");
            let linkUsed = localStorage.getItem("linkUsed");
    
            console.log("link  is",link);
    
            let userField = document.getElementById("username");
            // let password = document.getElementById("password").value;
            
            /*toaster for reg success*/
            // let boyImg = document.getElementsByClassName("boy-img")[0];
            // if(link == "reg"){
            //     let toast = document.getElementById("snackbar");
            //     let toastText = document.getElementById("toastText");
            //     //toastText.innerText = "Registered successfully. We've sent you an email for verification. Please verify to login.";
            //     toastText.innerText = registrationSuccessMsgRegistered;
            //     toast.className = "show";
            //     setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 5000);
            //     localStorage.clear();
            // }
            // if(eLink == "verified"){
            //     let toast = document.getElementById("snackbar");
            //     let toastText = document.getElementById("toastText");
            //     //toastText.innerText = "Email has been verified. Please login.";
            //     toastText.innerText = registrationSuccessMsgVerified;
            //     toast.className = "show";
            //     setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 5000);
            //     localStorage.clear();
            // }
            // if(pLink == "updated"){
            //     let toast = document.getElementById("snackbar");
            //     let toastText = document.getElementById("toastText");
            //     //toastText.innerText = "Password updated successfully.Please login.";
            //     toastText.innerText = registrationSuccessMsgUpdated;
            //     toast.className = "show";
            //     setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 5000);
            //     localStorage.clear();
            // }
            // if(linkUsed == "used"){
            //     let toast = document.getElementById("snackbar");
            //     let toastText = document.getElementById("toastText");
            //     //toastText.innerText = "Sorry! The link you’re trying to access has already been used.";
            //     toastText.innerText = registrationSuccessMsgUsed;
            //     toast.className = "show error";
            //     setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 5000);
            //     localStorage.clear();
            // }
            // if(errorTxt){
            //     let toast = document.getElementById("snackbar");
            //     let toastText = document.getElementById("toastText");
            //     toastText.innerText = errorTxt;
            //     toast.className = "show error";
            //     setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 5000);
            //     localStorage.clear();
            // }
            /*=============*/
            let feedbackTxt = document.getElementsByClassName("kc-feedback-text")[0];
            var loginBtn = document.getElementById("kc-form-buttons").children[0];
            var loginForm = document.getElementById("kc-form-login");
            console.log("Sign button text",loginBtn);
            loginBtn.disabled = true;
            if(feedbackTxt){
                console.log("feedback",feedbackTxt);
                let snackText = document.getElementsByClassName("snackText")[0];
                snackText.className = "snackText";
                snackText.innerText = "";
                loginForm.classList.add("error");
                
            }
            /*var loginBtn = document.getElementById("kc-form-buttons").children[0];
            loginBtn.disabled = true;*/
            setTimeout(function (){
                console.log("Initial user & pass are :",document.getElementById("username").value,document.getElementById("password").value);
                if(document.getElementById("username").value && document.getElementById("password").value){
                    console.log("Enabling login button 1");
                    loginBtn.disabled = false;
                }
            },300);
            setTimeout(function (){
                console.log("Autofilled class is",userField.className);
                if(userField.className.indexOf("autofilled")> -1){
                    console.log("Enabling login button 2");
                    loginBtn.disabled = false;
    
                }
            },300);
    
            _loginLibraryObject.loginFieldValidation = function(fieldId,field){
                // let emailRegex = /\S+@\S+\.\S+/;
                // let usernameRegex = /.{1,}$/i;
                let snackText = document.getElementsByClassName("snackText")[0];
                // let errorMsg = "";
                let isValid = true;
                if(fieldId == "username"){
                    if(field.value.length>0){
                        let isUsernameEmail = isUsernameEmailConfig;
                        if(isUsernameEmail){
                            //only email
                            if(emailRegex.test(field.value)){
                                // isValid = true;
                            }
                            else{
                                isValid = false;
                            }
                        }
                        else{
                            //any username and email
                            if(usernameRegex.test(field.value)){
                                // isValid = true;
                            }
                            else{
                                isValid = false;
                            }
                        }
                    }
                    // else{
                    //     isValid = false;
                    // }
                } 
                else if(fieldId == "password"){
                    if(field.value.length>0){
                        console.log("Password length",field.value.length);
                        if(field.value.length >= loginPasswordMinCharecters){
                            // isValid = true;
                        }
                        else{
                            isValid = false;
                        }
                    }
                }
                if(isValid){
                    field.style.border = "1px solid #E0E0E0";
                    field.style.background = "#FFFFFF";
                    field.classList.remove("error");
                    field.nextElementSibling.classList.remove("error");
                }
                else{
                    field.style.border = "1px solid #ED1C24";
                    field.style.background = "#FEFBFB 0% 0% no-repeat padding-box";
                    field.classList.add("error");
                    field.nextElementSibling.classList.add("error");
                }
                let usernameField = document.getElementById("username");
                let passField = document.getElementById("password");
                let isUsernameInvalid = usernameField.classList.contains('error');
                let isPasswordInvalid = passField.classList.contains('error');
                if(isUsernameInvalid || isPasswordInvalid){
                    snackText.className = "snackText error";
                    snackText.innerText = loginErrorMsgIncorrect;
                    var defaultError = document.getElementsByClassName("alert")[0];
                    console.log("defaultError",defaultError);
                    if(defaultError != undefined){
                        defaultError.parentNode.removeChild(defaultError);
                    }
                }
                else{
                    snackText.className = "snackText";
                    snackText.innerText = "";
                }
            }
            _loginLibraryObject.loginFieldChangeValidation = function(fieldId,field){
                // let emailRegex = /\S+@\S+\.\S+/;
                // let usernameRegex = /.{1,}$/i;
                let usernameField = document.getElementById("username");
                let passField = document.getElementById("password");
                let isUsernameEmail = isUsernameEmailConfig;
                if(fieldId == "username"){
                    if(field.value.length>0){
                        if(isUsernameEmail){
                            //only email
                            if(emailRegex.test(field.value)){
                                //validate password
                                if(passField.value.length >= loginPasswordMinCharecters){
                                    loginBtn.disabled = false;
                                }
                            }
                            else{
                                loginBtn.disabled = true;
                            }
                        }
                        else{
                            //any username and email
                            if(usernameRegex.test(field.value)){
                                //validate password
                                if(passField.value.length >= loginPasswordMinCharecters){
                                    loginBtn.disabled = false;
                                }
                            }
                            else{
                                loginBtn.disabled = true;
                            }
                        }
                    }
                    else{
                        loginBtn.disabled = true;
                    }
                } 
                else if(fieldId == "password"){
                    if(field.value.length>0){
                        if(field.value.length >= loginPasswordMinCharecters){
                            //validate username/email
                            if(isUsernameEmail){
                                if(emailRegex.test(usernameField.value)){
                                    loginBtn.disabled = false;
                                }
                            }
                            else{
                                if(usernameRegex.test(usernameField.value)){
                                    loginBtn.disabled = false;
                                }
                            }
                        }
                        else{
                                loginBtn.disabled = true;
                            }
                    }
                    else{
                        loginBtn.disabled = true;
                    }
                }
            }

            _loginLibraryObject.loginFieldChangeValidation1 = function(fieldId,field){
                // let emailRegex = /\S+@\S+\.\S+/;
                // let usernameRegex = /.{1,}$/i;
                let usernameField = document.getElementById("username");
                let passField = document.getElementById("password");
                let isUsernameEmail = isUsernameEmailConfig;
                if(fieldId == "username"){
                    if(field.value.length>0){
                        if(isUsernameEmail){
                            //only email
                            if(emailRegex.test(field.value)){
                                //validate password
                                if(passField.value.length >= loginPasswordMinCharecters){
                                    loginBtn.disabled = false;
                                }
                            }
                            else{
                                loginBtn.disabled = true;
                            }
                        }
                        else{
                            //any username and email
                            if(usernameRegex.test(field.value)){
                                //validate password
                                if(passField.value.length >= loginPasswordMinCharecters){
                                    loginBtn.disabled = false;
                                }
                            }
                            else{
                                loginBtn.disabled = true;
                            }
                        }
                    }
                    else{
                        loginBtn.disabled = true;
                    }
                } 
                else if(fieldId == "password"){
                    if(field.value.length>0){
                        if(field.value.length >= loginPasswordMinCharecters){
                            //validate username/email
                            if(isUsernameEmail){
                                if(emailRegex.test(usernameField.value)){
                                    loginBtn.disabled = false;
                                }
                            }
                            else{
                                if(usernameRegex.test(usernameField.value)){
                                    loginBtn.disabled = false;
                                }
                            }
                        }
                        else{
                                loginBtn.disabled = true;
                            }
                    }
                    else{
                        loginBtn.disabled = true;
                    }
                }
            }

            _loginLibraryObject.showPass = function(e){
                let passEye = document.getElementById("password");
                let openEye = document.getElementById("eye-icon-login");
                let closeEye = document.getElementById("eye-icon-close"); 
                console.log("iconSrc",e.src,openEye,closeEye,openEye.style);
    
                if(openEye.style.display == "block" || openEye.style.display == ""){
                    console.log("1");
                    openEye.style.display = "none";
                    closeEye.style.display = "block";
                }
                else if(openEye.style.display == "none"){
                    console.log("2");
                    openEye.style.display = "block";
                    closeEye.style.display = "none";
                }
                                
                if(passEye.type == "password"){
                    passEye.type = "text";
                }
                else{
                    passEye.type = "password";
                }
            }
    
        });
        }
        return _loginLibraryObject;
    }
    
    function templateScript(){
        let _templateLibraryObject = {};
        _templateLibraryObject.templateScriptFunction = function(){
        document.addEventListener('DOMContentLoaded', (event) => {
            _templateLibraryObject.closeToast = function(e) {
                let snackbar = document.getElementById("snackbar");
                snackbar.className = snackbar.className.replace("show", "");
            }
    
            console.log("inside template ftl");
            let cDate = document.getElementById("c-date");
            cDate.innerText = new Date().getFullYear();
            console.log("inside template ftl",cDate,new Date().getFullYear());
            /*close Icon click*/
            let closeLink  =  document.getElementsByClassName("close-icon")[0];
            console.log("callback url is :",closeLink);
            let uri_dec = decodeURIComponent(closeLink);
            let redirect_uri = "";
            if(uri_dec.indexOf("redirect_uri") > -1 ){
                console.log("index is",uri_dec.indexOf("redirect_uri"));
                redirect_uri = uri_dec.substr(uri_dec.lastIndexOf("=")+1,uri_dec.length);
                console.log("redirect_uri",redirect_uri,uri_dec.length,uri_dec.lastIndexOf("="));
            }
            console.log("decoded uri is :",uri_dec,"redirec uri is :",redirect_uri);
            //closeLink.href = redirect_uri;
        });
        }
        return _templateLibraryObject;
    }
    
    function registerScript(){
        let _registerLibraryObject = {};
        _registerLibraryObject.registerScriptFunction = function(registrationErrorMsgAlreadyRegistered,loginRegex,loginErrorMsgIncorrect){
            // let timeout = null;
            document.addEventListener('DOMContentLoaded', (event) => {
                let localization = document.getElementsByClassName("localization")[0];
                //localization.style.paddingRight = '70px';
                localization.classList.add('register-localization');
                let backLogin = document.getElementById("backLogin");
                let leftBg = document.getElementsByClassName('left-bg')[0];
                leftBg.className = 'col-lg-3 col-md-3 col-sm-3 col-xs-3 left-bg';
                let btmLine = document.getElementsByClassName('btm-line')[0];
                btmLine.className = 'btm-line col-lg-9 colmd-9 col-sm-9 colxs-9';
                //let bLink = document.getElementById("bLink");
                //let href = bLink.getAttribute("href");
                //console.log("caught href",bLink.getAttribute("href"));
                /*if(href.indexOf("redirect_uri")){
                    newHref = href.substring(href.length,href.lastIndexOf("=")+1);
                    console.log(newHref);
                    bLink.setAttribute("href",newHref);
                    console.log(bLink.getAttribute("href"));
                }*/
    
                /* Email Arlready Exists */
                let feedbackTxt = document.getElementsByClassName("kc-feedback-text")[0];
                if(feedbackTxt){
                    console.log("feedback",feedbackTxt);
                    // let emailExist = document.getElementsByClassName("kc-feedback-text")[0].innerText;
                    // let emailExist1 = emailExist.indexOf("Email already exists.");
                    // console.log("email Exist ",emailExist1);
                    // if(emailExist.indexOf("Email already exists.") > -1 ){
                        // let toast = document.getElementById("snackbar");
                        // toastText.innerText = registrationErrorMsgAlreadyRegistered;
                        // toast.className = "show error";
                        // setTimeout(function(){ 
                        //     toast.className = toast.className.replace("show", ""); 
                        //     backLogin.click();
                        //     }, 5000);
                    // }
                }
                
                /*Email Verified Successfully*/
                //let instruct = document.getElementsByClassName("instruction")[0];
                //if(instruct.innerText){
                //  alert("called from reg page");
                    //if(instruct.innerText.indexOf("Confirm validity of e-mail address") > -1){
                    //  let kcInfo = document.getElementById("kc-info-message");
                        //kcInfo.getElementsByTagName("a").click();
                    //}
                //}
    
                let borderClass = document.getElementsByClassName("login-left")[0];
                borderClass.className = "col-lg-12 col-md-12 col-sm-12 col-xs-12 login-right";
                
                // let isValidMail = true;
                // let isValidPass = true;
                var myBtn = document.getElementById("kc-form-buttons").children[0];
                myBtn.disabled = true;
                
                _registerLibraryObject.openModal = function openModalFunc(){
                    let pwdModal = document.getElementById("pwdModal");
                    pwdModal.style.display = "block";
    
                    // Get the <span> element that closes the modal
                    let span = document.getElementById("closeCriteria");
                    span.onclick = function(){
                        pwdModal.style.display = "none";
                    }
                }
            });
            
            //Show Password code
            _registerLibraryObject.showPass = function(){
                    let passEye = document.getElementById("password");
                    let openEye = document.getElementById("eye-icon-pass");
                    let closeEye = document.getElementById("eye-icon-close");
    
                    if(openEye.style.display == "block" || openEye.style.display == ""){
                        console.log("1");
                        openEye.style.display = "none";
                        closeEye.style.display = "block";
                    }
                    else if(openEye.style.display == "none"){
                        console.log("2");
                        openEye.style.display = "block";
                        closeEye.style.display = "none";
                    
                    }
                    if(passEye.type == "password"){
                        passEye.type = "text";
                    }
                    else{
                        passEye.type = "password";
                    }
                }
                _registerLibraryObject.showPassConfirm = function(){
                    let passEye = document.getElementById("password-confirm");
                    let openEye = document.getElementById("eye-icon-pass-confirm");
                    let closeEye = document.getElementById("eye-icon-close-confirm");
                    
                    if(openEye.style.display == "block" || openEye.style.display == ""){
                        console.log("1");
                        openEye.style.display = "none";
                        closeEye.style.display = "block";
                    }
                    else if(openEye.style.display == "none"){
                        console.log("2");
                        openEye.style.display = "block";
                        closeEye.style.display = "none";
                    
                    }
                    if(passEye.type == "password"){
                        passEye.type = "text";
                    }
                    else{
                        passEye.type = "password";
                    }
                }
            var checkAndEnableButton = function(){
                let firstName = document.getElementById("firstName").value;
                let lastName = document.getElementById("lastName").value;
                let email = document.getElementById("email").value;
                let emailOk = document.getElementById("emailOk").value;
                let password = document.getElementById("password").value;
                let passwordConfirm = document.getElementById("password-confirm").value;
                let myBtn = document.getElementById("kc-form-buttons").children[0];
    
                if(firstName != "" && lastName != "" && email != "" && emailOk != "" && password != "" && passwordConfirm != ""){
                    myBtn.disabled = false;
                }
                else{
                    myBtn.disabled = true;
                }
            }
    
            _registerLibraryObject.registerFieldsValidate = function(fieldId,field){
                let snackText = document.getElementsByClassName("snackText")[0];
                let nameRegex = /^[a-zA-Z]{0,}$/;
                // let nameRegex = loginRegex;
                console.log("nameregex",nameRegex);
                let emailRegex = /\S+@\S+\.\S+/;
                console.log("emailRegex",emailRegex);
                switch(fieldId){
                    case "firstName" : 
                        if(nameRegex.test(field.value)){
                            console.log("Valid first name");
                            field.style.border = "1px solid #E0E0E0";
                            field.nextElementSibling.classList.remove("error");
                            /*snackText.className = "snackText";
                            snackText.innerText = "";*/
                            checkAndEnableButton();
                        }
                        else{
                            console.log("Invalid first name");
                            field.style.border = "1px solid #ED1C24";
                            field.nextElementSibling.classList.add("error");
                            /*snackText.className = "snackText error";
                            snackText.innerText = "Please enter a valid first name";*/
                        }  
                        break;
                    case "lastName" : 
                        if(nameRegex.test(field.value)){
                            console.log("Valid last name");
                            field.style.border = "1px solid #E0E0E0";
                            field.nextElementSibling.classList.remove("error");
                            checkAndEnableButton();
                        }
                        else{
                            console.log("Invalid last name");
                            field.style.border = "1px solid #ED1C24";
                            field.nextElementSibling.classList.add("error");
                        }  
                        break;
                    case "email" : 
                        if(field.value.length > 0){
                            if(emailRegex.test(field.value)){
                                console.log("Valid email");
                                field.style.border = "1px solid #E0E0E0";
                                field.nextElementSibling.classList.remove("error");
                                checkAndEnableButton();
                            }
                            else{
                                console.log("Invalid email");
                                field.style.border = "1px solid #ED1C24";
                                field.nextElementSibling.classList.add("error");
                            }  
                        }
                        break;
                    case "emailOk" : 
                        if(field.value.length > 0){
                            if(emailRegex.test(field.value)){
                                console.log("Valid emailOk");
                                field.style.border = "1px solid #E0E0E0";
                                field.nextElementSibling.classList.remove("error");
                                if(field.value.length > 0){
                                    let email = document.getElementById("email").value;
                                    if(field.value == email){
                                        checkAndEnableButton();
                                    }
                                    else{
                                        field.style.border = "1px solid #ED1C24";
                                        field.nextElementSibling.classList.add("error")
                                    }
                                }
                            }
                            else{
                                console.log("Invalid emailOk");
                                field.style.border = "1px solid #ED1C24";
                                field.nextElementSibling.classList.add("error");
                            }  
                            break;
                        }
                    case "password" : 
                        if(field.value.length > 0){
                            var isValidPass = true;
                            if(field.value.length < 8) {
                                isValidPass = false;
                                //alert('atleast 8 char');
                                //document.getElementsByClassName("passError")[0].innerText += " " + "8 characters,";
                            } 
                            if(!/[A-Z]/.test(field.value)) {
                                isValidPass = false;
                                //alert('atleast One uppercase letter');
                                //document.getElementsByClassName("passError")[0].innerText += " " + "1 upper case letter,";
                            } 
                            if(!(/[a-z]/.test(field.value))) {
                                isValidPass = false;
                                //alert('atleast One lower letter');
                                //document.getElementsByClassName("passError")[0].innerText += " " + "1 lower case letter, ";
                            } 
                            if(!/[0-9]/.test(field.value)) {
                                isValidPass = false;
                                //alert('atleast One digit');
                                //document.getElementsByClassName("passError")[0].innerText += " " + "1 number, ";
                            }
                            if(!/[-!$%^&*()_+|~=`{}\[\]:\/;<>?,.@#]/.test(field.value)){
                                isValidPass = false;
                                //alert('atleast One spl chr');
                                //document.getElementsByClassName("passError")[0].innerText += " " + "1 special character ";
                            }
                            if(isValidPass){
                                console.log("Valid password");
                                field.style.border = "1px solid #E0E0E0";
                                field.nextElementSibling.classList.remove("error");
                                checkAndEnableButton();
                            }
                            else{
                                console.log("Invalid password");
                                field.style.border = "1px solid #ED1C24";
                                field.nextElementSibling.classList.add("error");
                            }
                        }
                        break;
                    case "password-confirm" : 
                        if(field.value.length > 0){
                            let password = document.getElementById("password").value;
                            if(field.value == password){
                                console.log("Valid confirm password");
                                field.style.border = "1px solid #E0E0E0";
                                field.nextElementSibling.classList.remove("error");
                                checkAndEnableButton();
                            }
                            else{
                                console.log("Invalid confirm password");
                                field.style.border = "1px solid #ED1C24";
                                field.nextElementSibling.classList.add("error");
                                snackText.className = "snackText error";
                                snackText.innerText = loginErrorMsgIncorrect;
                            }
                        }
                        break;
                }
            }
        }
        return _registerLibraryObject;
    }
    
    function loginVerifyEmailScript(){
        let _verifyEmailLibraryObject = {};
        _verifyEmailLibraryObject.verifyEmailScriptFunction = function(){
            document.addEventListener('DOMContentLoaded', (event) => {
                /*change boy Image*/
                //let boyImg = document.getElementsByClassName("boy-img")[0];
                //boyImg.className = "boy-img-error";
                
                //remove border right
                let borderClass = document.getElementsByClassName("login-left")[0];
                borderClass.className = "col-lg-12 col-md-12 col-sm-12 col-xs-12";
                console.log("referrer",document.referrer);
                let prevLocation = document.referrer;
                let action = prevLocation.includes("registration");
                console.log("action in verify",action);
                if(action){
                    localStorage.setItem("link", "reg");
                    //let card = document.getElementsByClassName("login-wrap")[0];
                    //card.style.display = "none";
                    /*Loader*/
                    let body = document.getElementsByTagName('body')[0];
                    const div = document.createElement('div');
                    div.className = "preloader";
                    div.style.display = "block";
                    div.innerHTML = '<div class="status" style="display:block;"></div>';
                    body.appendChild(div);
    
                    let bLink = document.getElementById("backLink");
                    let uri_dec = decodeURIComponent(bLink);
                    console.log("back link -----------",bLink,uri_dec);
                    window.location.href = uri_dec;
                    //document.getElementById("backLink").click();
                }
                /*Email verify case to show the email Id*/
                if(localStorage.getItem("email")){
                    // var email = localStorage.getItem("email");
                    if(localStorage.getItem("emailFrgt")){
                        localStorage.removeItem("emailFrgt");
                    }
                    document.getElementById("emailverify").value = localStorage.getItem("email");
                    //then show the toast
                    let toast = document.getElementById("snackbar");
                    let toastText = document.getElementById("toastText");
                    toastText.innerText = "Please verify yourself using the verification email sent to you, in order to login.";
                    toast.className = "show error";
                    setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 4000);
                }
                if(localStorage.getItem("emailFrgt")){
                    // var email = localStorage.getItem("emailFrgt");
                        if(localStorage.getItem("email")){
                            localStorage.removeItem("email");
                        }
                    document.getElementById("emailverify").value = localStorage.getItem("emailFrgt");
                    //then show the toast
                    let toast = document.getElementById("snackbar");
                    let toastText = document.getElementById("toastText");
                    toastText.innerText = "Please verify yourself using the verification email sent to you, in order to login.";
                    toast.className = "show error";
                    setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 4000);
                }
                document.getElementsByClassName("alert")[0].style.display = "none";
                document.getElementById("kc-content").style.display = "inline-grid";
            });
        }
        return _verifyEmailLibraryObject;
    }
    
    function loginResetPasswordScript(){
        let _resetPasswordLibraryObject = {};
        _resetPasswordLibraryObject.resetPasswordScriptFunction = function(isUsernameEmailConfig,loginIncorrectUsernameMsg){
    
            document.addEventListener('DOMContentLoaded', (event) => {
                //let location = window.location.pathname;
                //let realmStr = location.split("/");
                //let realm = realmStr[3];
                //console.log(location,realmStr,realm);
                //let action = location.includes("reset-credentials");
                //console.log(action);
                //if(action){
                    
                    if(window.innerWidth <= 850 && window.innerHeight <= 800) {
                        document.getElementById("kc-info").style.display = "none";
                    } 
                    else {
                        document.getElementById("kc-info").display = "block"
                    }
                    let username = document.getElementById("username");
                //}
                let borderClass = document.getElementsByClassName("login-left")[0];
                borderClass.className = "col-lg-8 col-md-8 col-sm-8 col-xs-8";
                
                var myBtn = document.getElementById("kc-form-buttons").children[0];
                myBtn.disabled = true;
    
                _resetPasswordLibraryObject.setEmailStorage = function setEmailStorage(){
                    username = document.getElementById("username");
                    localStorage.setItem("emailFrgt",username.value);
                    console.log("value set is :",username.value);
                }
                
                _resetPasswordLibraryObject.usernameValidation = function(field){
                    let emailRegex = /\S+@\S+\.\S+/;
                    let usernameRegex = /.{1,}$/i;
                    let snackText = document.getElementsByClassName("snackText")[0];
                    // let errorMsg = "";
                    let isValid = true;
                    if(field.value.length>0){
                        let isUsernameEmail = isUsernameEmailConfig;
                        if(isUsernameEmail){
                            //only email
                            if(emailRegex.test(field.value)){
                                // isValid = true;
                            }
                            else{
                                isValid = false;
                            }
                        }
                        else{
                            //any username and email
                            if(usernameRegex.test(field.value)){
                                // isValid = true;
                            }
                            else{
                                isValid = false;
                            }
                        }
                    }
                    if(isValid){
                        field.style.border = "1px solid #E0E0E0";
                        field.style.background = "#FFFFFF";
                        field.classList.remove("error");
                        field.nextElementSibling.classList.remove("error");
                    }
                    else{
                        field.style.border = "1px solid #ED1C24";
                        field.style.background = "#FEFBFB 0% 0% no-repeat padding-box";
                        field.classList.add("error");
                        field.nextElementSibling.classList.add("error");
                    }
                    let usernameField = document.getElementById("username");
                    let isUsernameInvalid = usernameField.classList.contains('error');
                    if(isUsernameInvalid){
                        snackText.className = "snackText error";
                        snackText.innerText = loginIncorrectUsernameMsg;
                    }
                    else{
                        snackText.className = "snackText";
                        snackText.innerText = "";
                    }
                }
                _resetPasswordLibraryObject.usernameChangeValidation = function(field){
                    let emailRegex = /\S+@\S+\.\S+/;
                    let usernameRegex = /.{1,}$/i;
                    // let usernameField = document.getElementById("username");
                    let isUsernameEmail = isUsernameEmailConfig;
                    if(field.value.length>0){
                        if(isUsernameEmail){
                            //only email
                            if(emailRegex.test(field.value)){
                                myBtn.disabled = false;
                            }
                            else{
                                myBtn.disabled = true;
                            }
                        }
                        else{
                            //any username and email
                            if(usernameRegex.test(field.value)){
                                myBtn.disabled = false;
                            }
                            else{
                                myBtn.disabled = true;
                            }
                        }
                    }
                }
            });
        }
        return _resetPasswordLibraryObject;
    }
    
    function loginUpdatePasswordScript(){
        let _updatePasswordLibraryObject = {};
        _updatePasswordLibraryObject.updatePasswordScriptFunction = function(){
            document.addEventListener('DOMContentLoaded', (event) => {
                
                var myBtn = document.getElementById("kc-form-buttons").children[0];
                myBtn.disabled = true;
            
                var isValid = true;
                let borderClass = document.getElementsByClassName("login-left")[0];
                borderClass.className = "col-lg-12 col-md-12 col-sm-12 col-xs-12 login-left";
            
                //let boyImg = document.getElementsByClassName("boy-img")[0];
                //boyImg.className = "lock-img";
            
                let feedbackTxt = document.getElementsByClassName("kc-feedback-text")[0];
                if(feedbackTxt){
                        
                        console.log("feedback",feedbackTxt);
                        // let emailExist = feedbackTxt && document.getElementsByClassName("kc-feedback-text")[0].innerText;
                        let emailExist = document.getElementsByClassName("kc-feedback-text")[0].innerText;
                        
                        if(emailExist.indexOf("Invalid password: must not be equal") > -1 ){
                            let passNew = document.getElementById("password-new");
                            let pwdConfirmField = document.getElementById("password-confirm");
            
                            passNew.style.border = "1px solid #ED1C24";
                            pwdConfirmField.style.border = "1px solid #ED1C24";
            
                            passNew.style.background = "#FEFBFB 0% 0% no-repeat padding-box";
                            pwdConfirmField.style.background = "#FEFBFB 0% 0% no-repeat padding-box";
            
                            //boyImg.className = "boy-img-error";
            
            
                            if(emailExist.indexOf(1) > -1){
                                emailExist = "You cannot use 1 recent password";
                            }
                            else if(emailExist.indexOf(2)> -1){
                                emailExist = "You cannot use 2 recent passwords";
                            }
                            else if(emailExist.indexOf(3) > -1){
                                emailExist = "You cannot use 3 recent passwords";
                            }
                            
                            let toast = document.getElementById("snackbar");
                            toastText.innerText = emailExist;
                            toast.className = "show error";
                            setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 3500);
                        }
                        
                        
                    }
                    _updatePasswordLibraryObject.passValidation = function validatePass(e,pass){
                                    //alert("entered password validation");
                                    let pwdField = document.getElementById("password-new");
                                    pwdField.style.border = "1px solid #E0E0E0";
                                //document.getElementsByClassName("passError")[0].innerText = "";
                                if(e.value.length < 1){
                                    myBtn.disabled = true;
                                    pwdField.style.border = "1px solid #E0E0E0";
                                    pwdField.style.background = "#FFFFFF";
                                    document.getElementsByClassName("passError")[0].style.display = "none";
                                    document.getElementsByClassName("passError")[0].innerText = "";
                                }
                                else if(e.value.length > 1){
                                    isValid = true;
                                    pwdField.style.border = "1px solid #ED1C24";
                                    pwdField.style.background = "#FEFBFB 0% 0% no-repeat padding-box";
                                    
                                    document.getElementsByClassName("passError")[0].innerText = "";
                                    document.getElementsByClassName("passError")[0].innerText = "Password must be atleast";
                                    document.getElementsByClassName("passError")[0].style.display = "block";
                                    if(e.value.length < 8) {
                                        isValid = false;
                                        document.getElementsByClassName("passError")[0].innerText += " " + "8 characters,";
                                        //alert('Minimum length = 8');
                                        myBtn.disabled = true;
                                    } 
                                    if(!/[A-Z]/.test(e.value)) {
                                        isValid = false;
                                        document.getElementsByClassName("passError")[0].innerText += " " + "1 upper case letter,";
                                        //alert('atleast One uppercase letter');
                                        myBtn.disabled = true;
                                    } 
                                    if(!(/[a-z]/.test(e.value))) {
                                        isValid = false;
                                        //alert('atleast One lowercase letter');
            
                                        document.getElementsByClassName("passError")[0].innerText += " " + "1 lower case letter, ";
                                        myBtn.disabled = true;
                                    } 
                                    if(!/[0-9]/.test(e.value)) {
                                        isValid = false;
                                        //alert('atleast number');
                                        document.getElementsByClassName("passError")[0].innerText += " " + "1 number, ";
                                        myBtn.disabled = true;
                                    }
                                    if(!/[-!$%^&*()_+|~=`{}\[\]:\/;<>?,.@#]/.test(e.value)){
                                        //alert('special character');
                                        isValid = false;
                                        document.getElementsByClassName("passError")[0].innerText += " " + "1 special character ";
                                        myBtn.disabled = true;
                                    }
                                    if(isValid){
                                        pwdField.style.border = "1px solid #E0E0E0";
                                        pwdField.style.background = "#FFFFFF";
                                        document.getElementsByClassName("passError")[0].style.display = "none";
                                        document.getElementsByClassName("passError")[0].innerText = "";
                                        myBtn.disabled = false;
                                    }
                                }
                                
                                //confirm password validation
            
                                    let pwd = e.value;
                                    let pwdConfirmField = document.getElementById("password-confirm");
                                    let pwdConfirm = pwdConfirmField.value;
                                    if(pwd.length > 1 && pwdConfirm.length > 1){
                                        if(pwd === pwdConfirm){
                                            console.log("here");
                                            document.getElementsByClassName("passErrorConfirm")[0].style.display = "none";
                                            pwdConfirmField.style.border = "1px solid #E0E0E0";
                                            pwdConfirmField.style.background = "#FFFFFF";
                                            myBtn.disabled = false;
                                        }
                                        else{
                                            console.log("hererererere   ")
                                            document.getElementsByClassName("passErrorConfirm")[0].style.display = "block";
                                            pwdConfirmField.style.border = "1px solid #ED1C24";
                                            pwdConfirmField.style.background = "#FEFBFB 0% 0% no-repeat padding-box";
                                            myBtn.disabled = true;
                                        }
                                    }
                                    if(pwdConfirm.length < 1 || pwd.length < 1){
                                        myBtn.disabled = true;
                                    }
                                console.log("pass valid :",e.value)
                }
                _updatePasswordLibraryObject.passValidationConfirm = function(e,pass){
                    console.log("confirm password is", e.value,pass);
                    let pwd = document.getElementById("password-new").value;
                    let pwdConfirm = e.value
                    let pwdConfirmField = document.getElementById("password-confirm");
                    if(pwd === pwdConfirm){
                        document.getElementsByClassName("passErrorConfirm")[0].style.display = "none";
                        pwdConfirmField.style.border = "1px solid #E0E0E0";
                        pwdConfirmField.style.background = "#FFFFF";
                        myBtn.disabled = isValid ? false : true;
                    }
                    else{
                        document.getElementsByClassName("passErrorConfirm")[0].style.display = "block";
                        pwdConfirmField.style.border = "1px solid #ED1C24";
                        pwdConfirmField.style.background = "#FEFBFB 0% 0% no-repeat padding-box";
                        myBtn.disabled = true;
                    }
                }
                _updatePasswordLibraryObject.openModal = function openModalFunc(){
                        let pwdModal = document.getElementById("pwdModal");
                        pwdModal.style.display = "block";
            
                        // Get the <span> element that closes the modal
                        let span = document.getElementById("closeCriteria");
                        span.onclick = function(){
                            pwdModal.style.display = "none";
                        }
                }
                _updatePasswordLibraryObject.showPass = function(){
                    let passEye = document.getElementById("password-confirm");
                    if(passEye.type == "password"){
                        passEye.type = "text";
                    }
                    else{
                        passEye.type = "password";
                    }
                }
            });
        }
        return _updatePasswordLibraryObject;
    }
    if(typeof(window.loginLibrary) === 'undefined' || typeof(window.templateLibrary) === 'undefined' || typeof(window.registerLibrary) === 'undefined' || typeof(window.verifyEmailLibrary) === 'undefined' || typeof(window.resetPasswordLibrary) === 'undefined' || typeof(window.updatePasswordLibrary) === 'undefined'){
        window.loginLibrary = loginScript();
        window.templateLibrary = templateScript();
        window.registerLibrary = registerScript();
        window.verifyEmailLibrary = loginVerifyEmailScript();
        window.resetPasswordLibrary = loginResetPasswordScript();
        window.updatePasswordLibrary = loginUpdatePasswordScript();
    }
    })(window);