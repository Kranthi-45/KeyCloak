window.addEventListener('load', function() {
    console.log('All assets are loaded',this.window.location);
});

document.addEventListener('DOMContentLoaded', (event) => {

//     frgtEmail = () => {
//         alert("hello");
//         let btn = document.createElement("BUTTON");
//         document.getElementById("kc-page-title").innerText = "Forgot Email / User ID";
//         document.getElementById("kc-page-subtitle").innerText = "Email / User ID will be sent to your registered contact number";
//         console.log(btn);
//   btn.innerHTML = "CLICK ME";
//   document.body.appendChild(btn);
//     }
    //the event occurred
    console.log("window location :",window.location.pathname);
    let location = window.location.pathname;
    let realmStr = location.split("/");
    let realm = realmStr[3];
    console.log(realmStr,realm);
    let action = location.includes("registration");

    console.log("action is :",action);
    //If action = Registration
    if(action){
    //     let contactNo = document.getElementById("user.attributes.mobileNumber");
    //     let otpField  = document.getElementById("user.attributes.otp");
    //     let email = document.getElementById("email");
        let bgImg = document.getElementsByClassName("login-bg")[0];
        // let boyImg = document.getElementsByClassName("boy-img")[0];

        console.log("bg Image is :",bgImg);
        bgImg.className = "login-bg login-bg-reg";
        //boyImg.className = "boy-img-reg";

    //     //email ID 
    //     email.addEventListener("", () => {
            
    //     })
    //     //validate OTP call
    //     otpField.addEventListener("blur", () => {
    //         let mobileObj = {
    //             "mobileNumber" : `${contactNo.value}`,
    //             "otp": `${otpField.value}`
    //         }
    //         AjaxRequest(`http://localhost:8080/auth/realms/${realm}/Rest-Provider/validate`,mobileObj,'POST');
    //     });


    //     contactNo.addEventListener("blur",() => {
    //         AjaxRequest(`http://localhost:8080/auth/realms/${realm}/Rest-Provider/validateMobileNumber/${contactNo.value}`,{},'GET');

    //             // xhttp.onreadystatechange = function() {
    //             //     if (this.readyState == 4 && this.status == 200) {
    //             //         console.log("responseText is",typeof(this.response));
    //             //         let response = JSON.parse(this.response);

    //             //         if(response["status_code"] == "SC0001"){
    //             //             alert("This Mobile number already exists. Please choose another number");
    //             //         }
    //             //         else if(response["status_code"] === "SC0000"){
    //             //             let otpField = document.getElementById("otp_wrap");
    //             //             otpField.style.display = "block";
    //             //             generateOTP(contactNo.value);
    //             //         }
    //             //     //document.getElementById("demo").innerHTML = this.responseText;
    //             //     }
    //             // };
    //     });
    }
    // const AjaxRequest = (url,obj,method) => {
    //     let xhttp = new XMLHttpRequest();
        
    //     xhttp.open(method,url,true);
    //     xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    //     xhttp.send(JSON.stringify(obj));

    //     xhttp.onreadystatechange = function() {
    //         if (this.readyState == 4 && this.status == 200) {
    //             console.log("responseText is",typeof(this.response));
    //             let response = JSON.parse(this.response);

    //             if(response["status_code"] == "SC0001"){
    //                 alert(response['status']);
    //             }
    //             else if(response["status_code"] === "SC0000"){
    //                 alert(response['status']);
    //             }
    //         //document.getElementById("demo").innerHTML = this.responseText;
    //         }
    //     };
    // }
    

    
        


    // generateOTP = function(contact){
    //     let xhttp = new XMLHttpRequest();
    //     let mobileObj = {
    //         "mobileNumber" : `${contact}`
    //     }
    //     xhttp.open("POST", `http://localhost:8080/auth/realms/${realm}/Rest-Provider/generate`, true);
    //     xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    //     xhttp.send(JSON.stringify(mobileObj));

    //     console.log("mobileObj",mobileObj);
    //     xhttp.onreadystatechange = function() {
    //         if (this.readyState == 4 && this.status == 200) {
    //             console.log("responseText is",typeof(this.response));
                
    //             let response = JSON.parse(this.response);

    //             if(response["status_code"] == "SC0001"){
    //                alert("in success");
    //             }
    //             else if(response["status_code"] === "SC0000"){
    //                 alert("OTP successfuly sent to the user");
    //             }
    //           //document.getElementById("demo").innerHTML = this.responseText;
    //         }
    //     };
    // }
    // validateEmail = function validateEmail(email) {
    //         var re = /\S+@\S+\.\S+/;
    //         return re.test(email);
    // }
    //console.log("action is :",action,contactNo);
  });

 