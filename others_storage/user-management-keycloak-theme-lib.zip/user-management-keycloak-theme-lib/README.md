## Repository details
| Product Group | Module Name | Name | Description |
|---------------|-------------|------------------|-------------|
| general | user-management | user-management-keycloak-theme-lib | user-management-keycloak-theme-lib